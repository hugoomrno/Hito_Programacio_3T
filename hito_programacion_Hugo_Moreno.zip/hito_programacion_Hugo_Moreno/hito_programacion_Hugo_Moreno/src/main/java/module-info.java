module com.empresa.hito_programacion_hugo_moreno {
    requires javafx.controls;
    requires javafx.fxml;
    requires mongo.java.driver;

    opens com.empresa.hito_programacion_hugo_moreno to javafx.fxml;
    exports com.empresa.hito_programacion_hugo_moreno;
}
