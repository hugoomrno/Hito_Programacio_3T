package com.empresa.hito_programacion_hugo_moreno;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import org.bson.Document;

public class HelloController {
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField ageField;
    @FXML
    private TextArea resultArea;

    private MongoClient mongoClient;
    private MongoDatabase database;

    @FXML
    protected void connectToDatabase() {
        try {
            String username = "Abc1234";
            String password = "123";
            String uri = String.format("mongodb+srv://%s:%s@cluster0.b8fzarn.mongodb.net/?retryWrites=true&w=majority", username, password);
            mongoClient = new MongoClient(new MongoClientURI(uri));
            database = mongoClient.getDatabase("testdb");
            showAlert("Conexión exitosa", "Conectado a la base de datos MongoDB");
        } catch (Exception e) {
            showAlert("Error de Conexión", "No se pudo conectar a la base de datos: " + e.getMessage());
        }
    }

    @FXML
    protected void createRecord() {
        try {
            if (nameField.getText().isEmpty() || ageField.getText().isEmpty()) {
                showAlert("Error de Validación", "Por favor, complete todos los campos.");
                return;
            }

            MongoCollection<Document> collection = database.getCollection("users");
            Document doc = new Document("name", nameField.getText()).append("age", Integer.parseInt(ageField.getText()));
            collection.insertOne(doc);
            resultArea.setText("Registro creado: " + doc.toJson());
        } catch (Exception e) {
            showAlert("Error", "No se pudo crear el registro: " + e.getMessage());
        }
    }

    @FXML
    protected void readRecords() {
        try {
            MongoCollection<Document> collection = database.getCollection("users");
            StringBuilder result = new StringBuilder();
            for (Document doc : collection.find()) {
                result.append(doc.toJson()).append("\n");
            }
            resultArea.setText(result.toString());
        } catch (Exception e) {
            showAlert("Error", "No se pudieron leer los registros: " + e.getMessage());
        }
    }

    @FXML
    protected void updateRecord() {
        try {
            MongoCollection<Document> collection = database.getCollection("users");
            Document query = new Document("name", "Test User");
            Document newData = new Document("name", "Updated User").append("age", 35);
            Document updateObject = new Document("$set", newData);
            collection.updateOne(query, updateObject);
            resultArea.setText("Registro actualizado");
        } catch (Exception e) {
            showAlert("Error", "No se pudo actualizar el registro: " + e.getMessage());
        }
    }

    @FXML
    protected void deleteRecord() {
        try {
            MongoCollection<Document> collection = database.getCollection("users");
            Document query = new Document("name", "Updated User");
            collection.deleteOne(query);
            resultArea.setText("Registro eliminado");
        } catch (Exception e) {
            showAlert("Error", "No se pudo eliminar el registro: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
